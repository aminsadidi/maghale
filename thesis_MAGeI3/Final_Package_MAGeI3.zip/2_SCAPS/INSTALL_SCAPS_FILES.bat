@echo off
REM Finds SCAPS and copies all structure (.def) files and scripts of this study into it
cd /d "%~dp0"
powershell -NoProfile -Command "$s = Get-ChildItem -Path C:\,D:\ -Filter 'scaps*.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1; if(-not $s){Write-Host 'SCAPS NOT FOUND'; exit 1}; $d=$s.DirectoryName; Set-Content -Path scaps_path.txt -Value $d; New-Item -ItemType Directory -Force -Path (Join-Path $d 'script') | Out-Null; Copy-Item def\*.def (Join-Path $d 'def') -Force; Copy-Item def\*.script (Join-Path $d 'script') -Force; Write-Host ('Installed into: ' + $d)"
if errorlevel 1 ( echo [ERROR] & pause & exit /b 1 )
echo DONE. Open SCAPS with Run as administrator, then Script set-up -^> choose a script -^> Execute script
pause
