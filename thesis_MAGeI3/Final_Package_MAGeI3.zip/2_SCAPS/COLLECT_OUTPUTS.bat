@echo off
REM Collects all outputs of this study (MG_R1_*, MG_F_*, MG_W3_*, MG_VAL_*) into scaps_outputs.zip next to this file
cd /d "%~dp0"
powershell -NoProfile -Command "$d = Get-Content scaps_path.txt; $f = @(Get-ChildItem -Path $d, (Join-Path $env:LOCALAPPDATA 'VirtualStore') -Recurse -Force -Include MG_R1_*,MG_F_*,MG_W3_*,MG_VAL_* -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Group-Object Name | ForEach-Object { $_.Group[0] }); Write-Host ('files found: ' + $f.Count); if ($f.Count -gt 0) { Compress-Archive -Path $f.FullName -DestinationPath scaps_outputs.zip -Force; Write-Host 'Created scaps_outputs.zip' }"
pause
