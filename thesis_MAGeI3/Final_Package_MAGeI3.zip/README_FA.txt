بسته کامل فصل چهارم پایان‌نامه MAGeI3 (شبیه‌سازی SCAPS-1D)

1_Thesis
  Thesis_with_Chapter4.docx   فایل ورد پایان‌نامه با فصل چهارم
  Chapter4_MAGeI3.pdf         پی‌دی‌اف فقط فصل چهارم برای مرور سریع

2_SCAPS
  def\        فایل‌های ساختار (.def) و اسکریپت‌های SCAPS
     00_validation_Bhattarai2021.def + MAGeI3_validation.script   اعتبارسنجی با مرجع [65]
     10..13_RERUN_*.def        ساختارهای بدون میان‌انداز / WOx / NiOx / V2O5
     MAGeI3_RERUN_stage1.script   گام اول (ضخامت و چگالی نقص جاذب)
     MAGeI3_RERUN_FULL.script     همه تحلیل‌های فصل در یک اجرا (101 شبیه‌سازی)
     MAGeI3_WOx_doping.script     بررسی همگرایی WOx در آلایش‌های مختلف
  INSTALL_SCAPS_FILES.bat   کپی فایل‌ها به پوشه SCAPS
  COLLECT_OUTPUTS.bat       جمع کردن خروجی‌ها در یک zip
  *.py                      کدهای ساخت فایل‌ها و تبدیل خروجی به CSV

  روش اجرا:
   1 روی INSTALL_SCAPS_FILES.bat دوبار کلیک کنید
   2 SCAPS را با Run as administrator باز کنید
   3 Script set-up > انتخاب MAGeI3_RERUN_FULL.script > Execute script
   4 بعد از پایان، COLLECT_OUTPUTS.bat را اجرا کنید

3_Figures   همه شکل‌های فصل چهارم (PNG با کیفیت بالا)

4_Data
  csv\                       داده عددی هر شکل و جدول
  Origin_Data_MAGeI3.xlsx    همان داده‌ها در یک فایل اکسل (هر برگه یک شکل) برای Origin
  خروجی خام SCAPS در فایل جداگانه SCAPS_raw_outputs_MAGeI3.zip است (اختیاری)

پارامترها: جاذب و Spiro از [65]، ITO و NiOx از [66]، TiO2 از [63]، WOx از [74]،
V2O5 از [62]، نقص‌های حجمی از جدول 3-3 [69]، نقص‌های فصل‌مشترک از [70]
(N_it = 1e15 cm-2، σ = 1e-19 cm2، توزیع گاوسی، Et = 0.6 eV)
